
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Select from 'react-select';

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);

  useEffect(() => {
    axios.get('https://restcountries.com/v3.1/all')   
      .then(response => {
        const countries = response.data;
        const countryOptions = countries.map(country => ({
          value: country.name.common,
          label: `${country.name.common} (${country.capital ? country.capital[0] : 'No capital'})`
        }));
        setOptions(countryOptions);
      })
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <div style={{ width: '300px', margin: 'auto', paddingTop: '50px' }}>
      <Select
        options={options}
        onInputChange={(inputValue) => setSearchTerm(inputValue)}
        onChange={(selected) => setSelectedOption(selected)}
        placeholder="Search for a country by name or capital"
      />
      {selectedOption && <div>Selected: {selectedOption.label}</div>}
    </div>
  );
};

export default SearchBar;


